<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="groundjian" tilewidth="32" tileheight="32" tilecount="12" columns="6">
 <image source="groundjian.png" width="192" height="64"/>
 <tile id="4">
  <properties>
   <property name="groundjian" value="true"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="Collidable" value="true"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="groundjian" value="true"/>
  </properties>
 </tile>
</tileset>
