
#pragma once
#ifndef __DOOR_SCENE_H__
#define __DOOR_SCENE_H__

#include "cocos2d.h"

cocos2d::Sprite* setDoor(float x, float y, float length);


#endif // __MAP_SCENE_H__