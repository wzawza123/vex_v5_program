#pragma once

extern int successLevelNum;
