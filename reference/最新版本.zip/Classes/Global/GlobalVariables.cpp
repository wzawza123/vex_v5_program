#include "Global/GlobalVariables.h"

int successLevelNum = 0;